"""
Talkscriber Python Client
~~~~~~~~~~~~~~~~~~~~~~~~

A Python client for interacting with the Talkscriber API.

:copyright: (c) 2024 Talkscriber
:license: MIT, see LICENSE for more details.
"""

from .client import TalkScriberClient

__version__ = "0.1.3"