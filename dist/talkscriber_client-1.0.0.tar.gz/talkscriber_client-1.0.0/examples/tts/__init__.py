"""
Text-to-Speech (TTS) Examples

This package contains examples demonstrating Talkscriber's text-to-speech
capabilities including real-time audio playback, file generation, batch
processing, and different voice options.
"""

__version__ = "1.0.0"
