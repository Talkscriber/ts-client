"""
Configuration Examples

This package contains examples demonstrating different configuration patterns
and best practices for using the Talkscriber client library in various
environments and use cases.
"""

__version__ = "1.0.0"
