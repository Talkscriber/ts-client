"""
Speech-to-Text (STT) Examples

This package contains examples demonstrating Talkscriber's live transcription
capabilities including real-time microphone transcription, file transcription,
and multilingual support.
"""

__version__ = "1.0.0"
