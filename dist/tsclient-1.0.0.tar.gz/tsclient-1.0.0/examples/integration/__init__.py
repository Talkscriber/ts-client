"""
Integration Examples

This package contains examples demonstrating integration patterns between
Talkscriber's STT and TTS services, including complete voice processing
pipelines and comprehensive demos.
"""

__version__ = "1.0.0"
